# -*- coding: utf-8 -*-
"""
AVA3 — PRÁTICA 2: PROTOCOLOS DE REPLICAÇÃO EM UMA PLATAFORMA DE PAGAMENTOS
Primário-secundário × quórum (5 nós), com detecção de falhas, eleição,
recuperação, versionamento e métricas de desempenho.

COMO FUNCIONA
-------------
Simulação de eventos discretos em um único processo Python (somente a
biblioteca padrão). O tempo é SIMULADO, em milissegundos:
  - cada mensagem leva entre 2 e 10 ms para chegar (sorteio com semente fixa);
  - os nós trocam heartbeats a cada 50 ms;
  - os tempos de detecção, eleição, retomada e ressincronização são medidos
    nesse relógio simulado.
Mesma semente => mesmos resultados (experimento reprodutível).

PROTOCOLOS
----------
1) PRIMÁRIO-SECUNDÁRIO (classe NoPrimarioSecundario)
   - um primário recebe todas as escritas e replica o log para os 4 secundários;
   - a escrita é confirmada ao cliente quando a maioria (3 de 5) gravou;
   - heartbeat a cada 50 ms; secundário sem heartbeat por 150–300 ms suspeita
     do primário e inicia uma ELEIÇÃO por votos, com épocas (terms);
   - o primário que perde contato com a maioria renuncia (check quorum) e só
     atende leituras com "lease" válido, evitando leituras desatualizadas;
   - nós que voltam são ressincronizados pelo primário (log replicado).

2) QUÓRUM (classe NoQuorum)
   - sem líder: qualquer nó coordena a operação do cliente;
   - escrita: lê a versão atual em R nós, cria a versão (contador+1, id do
     coordenador) e grava em W nós;
   - leitura: consulta R nós, devolve a maior versão e repara os atrasados
     (read repair);
   - conflito de versão (mesmo contador, coordenadores diferentes) é resolvido
     pelo maior par (contador, id);
   - detecção por heartbeat entre todos os nós; anti-entropia periódica e ao
     voltar de uma falha.

IMPORTANTE: não há rede real, processos reais nem disco; nenhum pagamento real
é processado. Os tempos são do relógio simulado.

USO
---
  python ava3_protocolos.py                 # todos os experimentos (30 sementes)
  python ava3_protocolos.py --sementes 5    # execução mais rápida
  python ava3_protocolos.py --demo          # linha do tempo comentada (semente 1)
"""
from __future__ import annotations

import argparse
import csv
import heapq
import random
import statistics
from pathlib import Path

# =============================================================================
# PARÂMETROS DO EXPERIMENTO
# =============================================================================
N = 5                                # número de nós
MAIORIA = N // 2 + 1                 # 3
LAT_MIN, LAT_MAX = 2.0, 10.0         # latência de uma mensagem (ms)
HB = 50.0                            # intervalo de heartbeat (ms)
ELEICAO_MIN, ELEICAO_MAX = 150.0, 300.0   # timeout de eleição (ms, sorteado)
SUSPEITA = 150.0                     # sem notícias por 150 ms => suspeito
LEASE = 100.0                        # validade do lease de leitura do primário
ANTI_ENTROPIA = 400.0                # sincronização periódica no quórum (ms)
TIMEOUT_TENTATIVA = 100.0            # cliente: espera por resposta (ms)
PRAZO_OPERACAO = 500.0               # cliente: desiste da operação (ms) -> "indisponível"
TIMEOUT_COORD = 80.0                 # coordenador do quórum: espera W/R (ms)
INTERVALO_CARGA = 20.0               # 1 escrita e 1 leitura a cada 20 ms
INICIO_CARGA = 300.0                 # carga começa após a eleição inicial
ASSENTAMENTO = 1000.0                # tempo sem carga antes da verificação final

SEM_VERSAO = (0, -1)


# =============================================================================
# NÚCLEO DA SIMULAÇÃO: relógio, fila de eventos, rede, falhas e partições
# =============================================================================
class Simulador:
    def __init__(self, semente: int, verbose: bool = False):
        self.rng = random.Random(semente)
        self.agora = 0.0
        self._fila: list = []
        self._seq = 0
        self.ativos = set(range(N))
        self.grupo = {i: 0 for i in range(N)}
        self.nos: dict = {}
        self.cliente = None
        self.eventos: list = []          # (t, tipo, no, alvo, texto)
        self.mensagens = 0
        self.verbose = verbose
        self.aguardando_sync: dict = {}  # no -> (t_retorno, {chave: valor})

    # ---- fila de eventos ----------------------------------------------------
    def agendar(self, atraso: float, fn, *args) -> None:
        self._seq += 1
        heapq.heappush(self._fila, (self.agora + atraso, self._seq, fn, args))

    def rodar_ate(self, t: float) -> None:
        while self._fila and self._fila[0][0] <= t:
            tt, _, fn, args = heapq.heappop(self._fila)
            self.agora = tt
            fn(*args)
        self.agora = max(self.agora, t)

    def registrar(self, tipo: str, no=None, alvo=None, texto: str = "") -> None:
        self.eventos.append((self.agora, tipo, no, alvo, texto))
        if self.verbose:
            print(f"  t={self.agora:7.1f} ms  [{tipo}] {texto}")

    # ---- rede ---------------------------------------------------------------
    def alcanca(self, a, b) -> bool:
        if a == "C":
            return b in self.ativos
        if b == "C":
            return a in self.ativos
        return a in self.ativos and b in self.ativos and self.grupo[a] == self.grupo[b]

    def enviar(self, origem, destino, msg: dict) -> None:
        if origem == destino:                       # chamada local, sem rede
            self.agendar(0.0, self._entregar, origem, destino, msg)
            return
        if not self.alcanca(origem, destino):       # nó parado ou partição
            return
        self.mensagens += 1
        self.agendar(self.rng.uniform(LAT_MIN, LAT_MAX), self._entregar, origem, destino, msg)

    def _entregar(self, origem, destino, msg: dict) -> None:
        if origem != destino and not self.alcanca(origem, destino):
            return                                  # perdida em trânsito
        if destino == "C":
            self.cliente.receber(origem, msg)
        elif destino in self.ativos:
            self.nos[destino].receber(origem, msg)

    # ---- falhas -------------------------------------------------------------
    def falhar(self, n: int) -> None:
        self.ativos.discard(n)
        self.nos[n].encarnacao += 1                 # invalida timers do nó
        self.registrar("FALHA", n, None, f"N{n} parou")

    def recuperar(self, n: int) -> None:
        self.ativos.add(n)
        confirmadas = {k: v[-1] for k, v in self.cliente.confirmadas.items()}
        self.aguardando_sync[n] = (self.agora, confirmadas)
        self.registrar("RETORNO", n, None, f"N{n} voltou e precisa se atualizar")
        self.nos[n].reiniciar()
        self.verificar_ressincronizacao(self.nos[n])

    def particionar(self, grupos) -> None:
        for gi, g in enumerate(grupos):
            for n in g:
                self.grupo[n] = gi
        desc = " / ".join("{" + ",".join(f"N{n}" for n in g) + "}" for g in grupos)
        self.registrar("REDE", None, None, f"partição {desc}")

    def curar(self) -> None:
        self.grupo = {i: 0 for i in range(N)}
        self.registrar("REDE", None, None, "rede restaurada")

    def verificar_ressincronizacao(self, no) -> None:
        if no.id not in self.aguardando_sync:
            return
        t_ret, exigido = self.aguardando_sync[no.id]
        estado = no.estado_visivel()
        for chave, valor in exigido.items():
            atual = estado.get(chave)
            if atual is None:
                return
            hist = self.cliente.confirmadas.get(chave, [])
            if atual != valor and (atual not in hist or hist.index(atual) < hist.index(valor)):
                return
        del self.aguardando_sync[no.id]
        self.registrar("RESSINCRONIZADO", no.id, None,
                       f"N{no.id} atualizado ({len(exigido)} pagamentos) em {self.agora - t_ret:.1f} ms")


# =============================================================================
# BASE DOS NÓS
# =============================================================================
class NoBase:
    def __init__(self, sim: Simulador, i: int):
        self.sim = sim
        self.id = i
        self.encarnacao = 0

    def timer(self, atraso: float, fn, *args) -> None:
        """Agenda um temporizador que morre se o nó falhar antes de disparar."""
        enc = self.encarnacao

        def disparar():
            if self.encarnacao == enc and self.id in self.sim.ativos:
                fn(*args)
        self.sim.agendar(atraso, disparar)

    def responder(self, m: dict, status: str, valor=None, versao=None) -> None:
        self.sim.enviar(self.id, "C", {"t": "RESP", "rid": m["rid"], "tent": m["tent"],
                                       "status": status, "valor": valor, "versao": versao})


# =============================================================================
# PROTOCOLO 1 — PRIMÁRIO-SECUNDÁRIO (log replicado, heartbeat, eleição)
# =============================================================================
class NoPrimarioSecundario(NoBase):
    def __init__(self, sim: Simulador, i: int):
        super().__init__(sim, i)
        # estado "estável" (sobrevive à falha; simula armazenamento durável)
        self.epoca = 0
        self.votou_em = None
        self.log: list = []
        self._tok_eleicao = 0
        self._tok_hb = 0
        self._volatil()

    def _volatil(self) -> None:
        self.papel = "SECUNDARIO"
        self.lider = None
        self.commit = 0
        self.aplicado = 0
        self.estado: dict = {}
        self.prox: dict = {}
        self.casado: dict = {}
        self.ultimo_ack: dict = {}
        self.votos: set = set()
        self.pendentes: dict = {}
        self.suspeitos: set = set()
        self.prevotos: set = set()
        self.ultimo_lider_t = None      # último heartbeat válido recebido
        self.suspeitando = False

    def estado_visivel(self) -> dict:
        return self.estado

    def iniciar(self, primeiro: bool = False) -> None:
        self._armar_eleicao(10.0 if primeiro else None)

    def reiniciar(self) -> None:
        self._volatil()
        self.estado = {}
        self._armar_eleicao()

    # ---- temporizador de eleição (detecção de falha do primário) -----------
    def _armar_eleicao(self, atraso=None) -> None:
        self._tok_eleicao += 1
        tok = self._tok_eleicao
        if atraso is None:
            atraso = self.sim.rng.uniform(ELEICAO_MIN, ELEICAO_MAX)
        self.timer(atraso, self._estouro_eleicao, tok)

    def _estouro_eleicao(self, tok: int) -> None:
        """Timeout sem heartbeat: suspeita do primário e faz uma PRÉ-VOTAÇÃO.
        A pré-votação (pre-vote) só vira eleição real se a maioria também estiver
        sem primário; assim um nó isolado não infla a época nem derruba o líder."""
        if tok != self._tok_eleicao or self.papel == "PRIMARIO":
            return
        if not self.suspeitando:
            self.suspeitando = True
            self.sim.registrar("SUSPEITA_PRIMARIO", self.id, None,
                               f"N{self.id} ficou sem heartbeat do primário e pede pré-votos")
        self.lider = None
        self.prevotos = {self.id}
        ult_ep = self.log[-1]["epoca"] if self.log else 0
        for j in range(N):
            if j != self.id:
                self.sim.enviar(self.id, j, {"t": "PRE_VOTO_REQ", "proposta": self.epoca + 1, "cand": self.id,
                                             "ult_idx": len(self.log), "ult_ep": ult_ep})
        self._armar_eleicao()

    def _iniciar_eleicao(self) -> None:
        self.epoca += 1
        self.papel = "CANDIDATO"
        self.votou_em = self.id
        self.votos = {self.id}
        self.sim.registrar("ELEICAO", self.id, None, f"N{self.id} inicia a eleição da época {self.epoca}")
        ult_ep = self.log[-1]["epoca"] if self.log else 0
        for j in range(N):
            if j != self.id:
                self.sim.enviar(self.id, j, {"t": "VOTO_REQ", "epoca": self.epoca, "cand": self.id,
                                             "ult_idx": len(self.log), "ult_ep": ult_ep})
        self._armar_eleicao()

    def _ouviu_lider_recentemente(self) -> bool:
        if self.papel == "PRIMARIO":
            return True
        return self.ultimo_lider_t is not None and self.sim.agora - self.ultimo_lider_t < ELEICAO_MIN

    def _log_atualizado(self, m: dict) -> bool:
        ult_ep = self.log[-1]["epoca"] if self.log else 0
        return (m["ult_ep"] > ult_ep) or (m["ult_ep"] == ult_ep and m["ult_idx"] >= len(self.log))

    def _pre_voto_req(self, origem, m: dict) -> None:
        concede = (m["proposta"] > self.epoca and not self._ouviu_lider_recentemente() and self._log_atualizado(m))
        self.sim.enviar(self.id, origem, {"t": "PRE_VOTO_RESP", "epoca": self.epoca,
                                          "proposta": m["proposta"], "concedido": concede})

    def _pre_voto_resp(self, origem, m: dict) -> None:
        if self.papel == "PRIMARIO" or not m["concedido"] or m["proposta"] != self.epoca + 1:
            return
        self.prevotos.add(origem)
        if len(self.prevotos) >= MAIORIA and self.papel in ("SECUNDARIO", "CANDIDATO"):
            self.prevotos = set()              # evita iniciar duas eleições com a mesma rodada
            self._iniciar_eleicao()

    def _tornar_secundario(self, epoca: int) -> None:
        if epoca > self.epoca:
            self.epoca = epoca
            self.votou_em = None
        if self.papel == "PRIMARIO":
            self._tok_hb += 1
        self.papel = "SECUNDARIO"
        self._armar_eleicao()

    # ---- despacho de mensagens ---------------------------------------------
    def receber(self, origem, m: dict) -> None:
        if m["t"] == "REQ":
            self._requisicao_cliente(m)
            return
        if m["t"] == "VOTO_REQ" and self._ouviu_lider_recentemente():
            return                          # "leader stickiness": ignora quem tenta derrubar um líder ativo
        if m["t"] != "PRE_VOTO_REQ" and m.get("epoca", 0) > self.epoca:
            self._tornar_secundario(m["epoca"])
            self.lider = None
        {"APPEND": self._append, "APPEND_RESP": self._append_resp,
         "VOTO_REQ": self._voto_req, "VOTO_RESP": self._voto_resp,
         "PRE_VOTO_REQ": self._pre_voto_req, "PRE_VOTO_RESP": self._pre_voto_resp}[m["t"]](origem, m)

    # ---- eleição ------------------------------------------------------------
    def _voto_req(self, origem, m: dict) -> None:
        concede = (m["epoca"] == self.epoca and self.votou_em in (None, m["cand"]) and self._log_atualizado(m))
        if concede:
            self.votou_em = m["cand"]
            self._armar_eleicao()
        self.sim.enviar(self.id, origem, {"t": "VOTO_RESP", "epoca": self.epoca, "concedido": concede})

    def _voto_resp(self, origem, m: dict) -> None:
        if self.papel != "CANDIDATO" or m["epoca"] != self.epoca or not m["concedido"]:
            return
        self.votos.add(origem)
        if len(self.votos) >= MAIORIA:
            self._assumir()

    def _assumir(self) -> None:
        self.papel = "PRIMARIO"
        self.lider = self.id
        outros = [j for j in range(N) if j != self.id]
        self.prox = {j: len(self.log) for j in outros}
        self.casado = {j: 0 for j in outros}
        self.ultimo_ack = {j: self.sim.agora for j in outros}
        self.suspeitos = set()
        self.log.append({"epoca": self.epoca, "chave": None, "valor": None, "rid": None})  # no-op
        self.sim.registrar("ELEITO", self.id, None,
                           f"N{self.id} venceu a eleição com {len(self.votos)} votos (época {self.epoca})")
        self._tok_hb += 1
        self._tick_hb(self._tok_hb)

    # ---- heartbeat e replicação (lado do primário) --------------------------
    def _tick_hb(self, tok: int) -> None:
        if tok != self._tok_hb or self.papel != "PRIMARIO":
            return
        agora = self.sim.agora
        com_contato = 1 + sum(1 for t in self.ultimo_ack.values() if agora - t <= ELEICAO_MAX)
        if com_contato < MAIORIA:   # check quorum: primário isolado renuncia
            self.sim.registrar("PRIMARIO_RENUNCIA", self.id, None,
                               f"N{self.id} perdeu contato com a maioria e deixa de ser primário")
            self._tornar_secundario(self.epoca)
            self.lider = None
            return
        for j, t in self.ultimo_ack.items():
            if agora - t > SUSPEITA and j not in self.suspeitos:
                self.suspeitos.add(j)
                self.sim.registrar("SUSPEITA_SECUNDARIO", self.id, j,
                                   f"primário N{self.id} suspeita de N{j} (sem resposta há {agora - t:.0f} ms)")
        for j in self.prox:
            self._replicar(j)
        self.timer(HB, self._tick_hb, tok)

    def _replicar(self, j: int) -> None:
        p = self.prox[j]
        self.sim.enviar(self.id, j, {"t": "APPEND", "epoca": self.epoca, "lider": self.id,
                                     "prev_idx": p, "prev_ep": self.log[p - 1]["epoca"] if p > 0 else 0,
                                     "entradas": self.log[p:p + 50], "commit": self.commit})

    def _append_resp(self, origem, m: dict) -> None:
        if self.papel != "PRIMARIO" or m["epoca"] != self.epoca:
            return
        self.ultimo_ack[origem] = self.sim.agora
        if origem in self.suspeitos:
            self.suspeitos.discard(origem)
            self.sim.registrar("SUSPEITA_DESFEITA", self.id, origem, f"N{origem} voltou a responder ao primário")
        if m["ok"]:
            self.casado[origem] = max(self.casado[origem], m["casado"])
            self.prox[origem] = max(self.prox[origem], self.casado[origem])
            self._avancar_commit()
            if self.prox[origem] < len(self.log) and m["casado"] == self.prox[origem]:
                self._replicar(origem)
        else:
            self.prox[origem] = max(0, min(self.prox[origem] - 1, m["casado"]))
            self._replicar(origem)

    def _avancar_commit(self) -> None:
        for n_idx in range(len(self.log), self.commit, -1):
            if self.log[n_idx - 1]["epoca"] != self.epoca:
                break
            if 1 + sum(1 for c in self.casado.values() if c >= n_idx) >= MAIORIA:
                self.commit = n_idx
                self._aplicar()
                self._responder_pendentes()
                break

    def _aplicar(self) -> None:
        for idx in range(self.aplicado, self.commit):
            e = self.log[idx]
            if e["chave"] is not None:
                self.estado[e["chave"]] = e["valor"]
        self.aplicado = max(self.aplicado, self.commit)

    def _responder_pendentes(self) -> None:
        for idx in [i for i in self.pendentes if i < self.commit]:
            for m in self.pendentes.pop(idx):
                self.responder(m, "OK", self.log[idx]["valor"])

    # ---- lado do secundário ---------------------------------------------------
    def _append(self, origem, m: dict) -> None:
        if m["epoca"] < self.epoca:
            self.sim.enviar(self.id, origem, {"t": "APPEND_RESP", "epoca": self.epoca, "ok": False, "casado": 0})
            return
        if self.papel != "SECUNDARIO":
            self._tornar_secundario(m["epoca"])
        self.lider = m["lider"]
        self.ultimo_lider_t = self.sim.agora
        self.suspeitando = False
        self._armar_eleicao()                       # heartbeat recebido: zera o timeout
        prev = m["prev_idx"]
        if prev > len(self.log) or (prev > 0 and self.log[prev - 1]["epoca"] != m["prev_ep"]):
            self.sim.enviar(self.id, origem, {"t": "APPEND_RESP", "epoca": self.epoca, "ok": False,
                                              "casado": min(len(self.log), max(prev - 1, 0))})
            return
        for k, e in enumerate(m["entradas"]):
            idx = prev + k
            if idx < len(self.log):
                if self.log[idx]["epoca"] != e["epoca"]:
                    descartadas = len(self.log) - idx
                    self.log = self.log[:idx]
                    self.sim.registrar("LOG_TRUNCADO", self.id, None,
                                       f"N{self.id} descartou {descartadas} entrada(s) nunca confirmada(s)")
                    self.log.append(e)
            else:
                self.log.append(e)
        fim = prev + len(m["entradas"])
        if m["commit"] > self.commit:
            self.commit = max(self.commit, min(m["commit"], fim))
            self._aplicar()
        self.sim.enviar(self.id, origem, {"t": "APPEND_RESP", "epoca": self.epoca, "ok": True, "casado": fim})
        self.sim.verificar_ressincronizacao(self)

    # ---- requisições do cliente ---------------------------------------------
    def _requisicao_cliente(self, m: dict) -> None:
        if self.papel != "PRIMARIO":
            self.sim.enviar(self.id, "C", {"t": "REDIR", "rid": m["rid"], "tent": m["tent"], "lider": self.lider})
            return
        if m["op"] == "leitura":
            agora = self.sim.agora
            lease = 1 + sum(1 for t in self.ultimo_ack.values() if agora - t <= LEASE) >= MAIORIA
            noop_ok = self.commit > 0 and self.log[self.commit - 1]["epoca"] == self.epoca
            if not (lease and noop_ok):
                self.responder(m, "OCUPADO")
                return
            self.responder(m, "OK", self.estado.get(m["chave"]))
            return
        existente = None
        for idx, e in enumerate(self.log):
            if e["chave"] == m["chave"]:
                existente = (idx, e)
        if m["modo"] == "criar" and existente is not None:
            idx, e = existente
            if e["rid"] == m["rid"]:                # retentativa da mesma requisição
                if idx < self.commit:
                    self.responder(m, "OK", e["valor"])
                else:
                    self.pendentes.setdefault(idx, []).append(m)
                return
            if idx >= self.commit:
                self.responder(m, "OCUPADO")
                return
            mesmo = e["valor"].split("#")[0] == m["valor"].split("#")[0]
            self.responder(m, "DUPLICADA" if mesmo else "REJEITADA_ID_CONFLITANTE", e["valor"])
            return
        self.log.append({"epoca": self.epoca, "chave": m["chave"], "valor": m["valor"], "rid": m["rid"]})
        self.pendentes.setdefault(len(self.log) - 1, []).append(m)
        for j in self.prox:
            self._replicar(j)


# =============================================================================
# PROTOCOLO 2 — QUÓRUM (N, R, W) COM VERSIONAMENTO
# =============================================================================
class NoQuorum(NoBase):
    def __init__(self, sim: Simulador, i: int, W: int, R: int):
        super().__init__(sim, i)
        self.W, self.R = W, R
        self.kv: dict = {}          # chave -> (versao, valor)   (estado "estável")
        self.conflitos = 0
        self._volatil()

    def _volatil(self) -> None:
        self.ops: dict = {}
        self.visto = {j: self.sim.agora for j in range(N) if j != self.id}
        self.suspeitos: set = set()
        self.seq_op = 0

    def estado_visivel(self) -> dict:
        return {k: v[1] for k, v in self.kv.items()}

    def iniciar(self, primeiro: bool = False) -> None:
        self.timer(self.sim.rng.uniform(0, HB), self._tick_hb)
        self.timer(self.sim.rng.uniform(0, ANTI_ENTROPIA), self._anti_entropia)

    def reiniciar(self) -> None:
        self._volatil()
        self._tick_hb()
        self.sim.registrar("ANTI_ENTROPIA", self.id, None, f"N{self.id} pede o estado aos pares")
        for j in range(N):
            if j != self.id:
                self.sim.enviar(self.id, j, {"t": "SYNC_REQ"})
        self.timer(ANTI_ENTROPIA, self._anti_entropia)

    # ---- detecção de falhas (heartbeat entre todos) --------------------------
    def _tick_hb(self) -> None:
        for j in range(N):
            if j != self.id:
                self.sim.enviar(self.id, j, {"t": "PING"})
        agora = self.sim.agora
        for j, t in self.visto.items():
            if agora - t > SUSPEITA and j not in self.suspeitos:
                self.suspeitos.add(j)
                self.sim.registrar("SUSPEITA", self.id, j, f"N{self.id} suspeita de N{j} (sem heartbeat há {agora - t:.0f} ms)")
        self.timer(HB, self._tick_hb)

    def _anti_entropia(self) -> None:
        pares = [j for j in range(N) if j != self.id and j not in self.suspeitos]
        if pares:
            self.sim.enviar(self.id, self.sim.rng.choice(pares), {"t": "SYNC_REQ"})
        self.timer(ANTI_ENTROPIA, self._anti_entropia)

    # ---- despacho --------------------------------------------------------------
    def receber(self, origem, m: dict) -> None:
        if origem != "C" and origem != self.id:
            self.visto[origem] = self.sim.agora
            if origem in self.suspeitos:
                self.suspeitos.discard(origem)
                self.sim.registrar("SUSPEITA_DESFEITA", self.id, origem, f"N{self.id} voltou a ouvir N{origem}")
        t = m["t"]
        if t == "PING":
            return
        if t == "REQ":
            self._coordenar(m)
        elif t == "LER":
            v = self.kv.get(m["chave"], (SEM_VERSAO, None))
            self.sim.enviar(self.id, origem, {"t": "LER_RESP", "op": m["op"], "versao": v[0], "valor": v[1]})
        elif t in ("GRAVAR", "REPARO"):
            self._gravar_local(m["chave"], m["versao"], m["valor"])
            if t == "GRAVAR":
                self.sim.enviar(self.id, origem, {"t": "GRAVAR_ACK", "op": m["op"]})
        elif t == "SYNC_REQ":
            self.sim.enviar(self.id, origem, {"t": "SYNC_RESP", "kv": dict(self.kv)})
        elif t == "SYNC_RESP":
            for chave, (versao, valor) in m["kv"].items():
                self._gravar_local(chave, versao, valor)
            self.sim.verificar_ressincronizacao(self)
        elif t == "LER_RESP":
            self._ler_resp(origem, m)
        elif t == "GRAVAR_ACK":
            self._gravar_ack(origem, m)

    def _gravar_local(self, chave, versao, valor) -> None:
        atual = self.kv.get(chave, (SEM_VERSAO, None))
        if versao[0] == atual[0][0] and versao[1] != atual[0][1] and valor != atual[1] and atual[0] != SEM_VERSAO:
            self.conflitos += 1
            vencedor = max(versao, atual[0])
            self.sim.registrar("CONFLITO_VERSAO", self.id, None,
                               f"N{self.id}: versões concorrentes v{versao[0]}@N{versao[1]} e "
                               f"v{atual[0][0]}@N{atual[0][1]} de {chave}; vence v{vencedor[0]}@N{vencedor[1]}")
        if versao > atual[0]:
            self.kv[chave] = (versao, valor)

    # ---- coordenação de leitura e escrita -------------------------------------
    def _coordenar(self, m: dict) -> None:
        self.seq_op += 1
        op_id = (self.id, self.encarnacao, self.seq_op)
        self.ops[op_id] = {"m": m, "fase": "ler", "resps": {}, "acks": set()}
        for j in range(N):
            self.sim.enviar(self.id, j, {"t": "LER", "op": op_id, "chave": m["chave"]})
        self.timer(TIMEOUT_COORD, self._timeout_op, op_id, "ler")

    def _ler_resp(self, origem, m: dict) -> None:
        st = self.ops.get(m["op"])
        if not st or st["fase"] != "ler":
            return
        st["resps"][origem] = (m["versao"], m["valor"])
        if len(st["resps"]) >= self.R:
            self._leitura_concluida(m["op"])

    def _leitura_concluida(self, op_id) -> None:
        st = self.ops[op_id]
        m = st["m"]
        melhor = max(st["resps"].values(), key=lambda x: x[0])
        if m["op"] == "leitura":
            self._encerrar(op_id, "OK", melhor[1], melhor[0])
            for j, (v, _) in st["resps"].items():          # read repair
                if v < melhor[0]:
                    self.sim.enviar(self.id, j, {"t": "REPARO", "chave": m["chave"], "versao": melhor[0], "valor": melhor[1]})
            return
        if m["modo"] == "criar" and melhor[1] is not None and melhor[1] != m["valor"]:  # idempotência
            mesmo = melhor[1].split("#")[0] == m["valor"].split("#")[0]
            self._encerrar(op_id, "DUPLICADA" if mesmo else "REJEITADA_ID_CONFLITANTE", melhor[1], melhor[0])
            return
        if melhor[1] == m["valor"]:
            # retentativa da MESMA requisição: a gravação anterior pode ter sido
            # parcial; regrava a mesma versão e só confirma com W réplicas
            nova = melhor[0]
        else:
            nova = (melhor[0][0] + 1, self.id)            # versionamento
        st["fase"] = "gravar"
        st["versao"] = nova
        for j in range(N):
            self.sim.enviar(self.id, j, {"t": "GRAVAR", "op": op_id, "chave": m["chave"], "versao": nova, "valor": m["valor"]})
        self.timer(TIMEOUT_COORD, self._timeout_op, op_id, "gravar")

    def _gravar_ack(self, origem, m: dict) -> None:
        st = self.ops.get(m["op"])
        if not st or st["fase"] != "gravar":
            return
        st["acks"].add(origem)
        if len(st["acks"]) >= self.W:
            self._encerrar(m["op"], "OK", st["m"]["valor"], st["versao"])

    def _timeout_op(self, op_id, fase: str) -> None:
        st = self.ops.get(op_id)
        if st and st["fase"] == fase:
            self._encerrar(op_id, "FALHA_QUORUM")

    def _encerrar(self, op_id, status: str, valor=None, versao=None) -> None:
        st = self.ops.pop(op_id)
        self.responder(st["m"], status, valor, versao)


# =============================================================================
# CLIENTE (gera a carga, tenta de novo e registra latência e consistência)
# =============================================================================
class Cliente:
    def __init__(self, sim: Simulador, protocolo: str):
        self.sim = sim
        self.protocolo = protocolo
        self.pend: dict = {}
        self.rid = 0
        self.lider = 0
        self.rr = 0
        self.resultados: list = []
        self.confirmadas: dict = {}   # chave -> valores confirmados, em ordem

    def operar(self, op: str, chave: str, valor=None, modo: str = "criar", alvo=None, cenario: str = "") -> int:
        self.rid += 1
        rid = self.rid
        if valor is not None:
            valor = f"{valor}#w{rid}"
        if alvo is None:
            if self.protocolo == "PS":
                alvo = self.lider
            else:
                alvo = self.rr
                self.rr = (self.rr + 1) % N
        st = {"rid": rid, "op": op, "chave": chave, "valor": valor, "modo": modo, "alvo": alvo,
              "inicio": self.sim.agora, "tent": 0, "tentativas": 0, "cenario": cenario, "falhos": set()}
        if op == "leitura":
            hist = self.confirmadas.get(chave, [])
            st["esperado"] = hist[-1] if hist else None
        self.pend[rid] = st
        self._tentar(rid)
        return rid

    def _tentar(self, rid: int) -> None:
        st = self.pend.get(rid)
        if st is None:
            return
        if self.sim.agora - st["inicio"] >= PRAZO_OPERACAO:
            self._finalizar(rid, "INDISPONIVEL")
            return
        st["tent"] += 1
        st["tentativas"] += 1
        self.sim.enviar("C", st["alvo"], {"t": "REQ", "rid": rid, "tent": st["tent"], "op": st["op"],
                                          "chave": st["chave"], "valor": st["valor"], "modo": st["modo"]})
        self.sim.agendar(TIMEOUT_TENTATIVA, self._estouro, rid, st["tent"])

    def _proximo(self, st: dict) -> int:
        """Próximo nó ainda não descartado nesta operação (round-robin)."""
        if len(st["falhos"]) >= N:
            st["falhos"].clear()
        alvo = (st["alvo"] + 1) % N
        while alvo in st["falhos"]:
            alvo = (alvo + 1) % N
        return alvo

    def _estouro(self, rid: int, tent: int) -> None:
        st = self.pend.get(rid)
        if st and st["tent"] == tent:
            st["falhos"].add(st["alvo"])
            st["alvo"] = self._proximo(st)
            self._tentar(rid)

    def _nova_tentativa(self, rid: int, alvo, atraso: float) -> None:
        st = self.pend[rid]
        st["tent"] += 1                      # invalida o timeout da tentativa atual
        st["alvo"] = alvo
        self.sim.agendar(atraso, self._tentar, rid)

    def receber(self, origem, m: dict) -> None:
        st = self.pend.get(m["rid"])
        if st is None:
            return
        if m["t"] == "REDIR":
            if m["tent"] != st["tent"]:
                return
            st["falhos"].add(origem)
            if m["lider"] is not None and m["lider"] != origem and m["lider"] not in st["falhos"]:
                self.lider = m["lider"]
                self._nova_tentativa(m["rid"], m["lider"], 0.0)
            else:
                st["alvo"] = origem
                self._nova_tentativa(m["rid"], self._proximo(st), 20.0)
            return
        status = m["status"]
        if status in ("FALHA_QUORUM", "OCUPADO"):
            if m["tent"] != st["tent"]:
                return
            if status == "FALHA_QUORUM":
                st["falhos"].add(origem)
                st["alvo"] = origem
            prox = self._proximo(st) if status == "FALHA_QUORUM" else origem
            self._nova_tentativa(m["rid"], prox, 0.0 if status == "FALHA_QUORUM" else 20.0)
            return
        if self.protocolo == "PS":
            self.lider = origem
        self._finalizar(m["rid"], status, m.get("valor"), m.get("versao"))

    def _finalizar(self, rid: int, status: str, valor=None, versao=None) -> None:
        st = self.pend.pop(rid)
        agora = self.sim.agora
        reg = {"cenario": st["cenario"], "op": st["op"], "chave": st["chave"], "status": status,
               "t_inicio": round(st["inicio"], 2), "t_fim": round(agora, 2),
               "latencia_ms": round(agora - st["inicio"], 2), "tentativas": st["tentativas"],
               "valor_enviado": st["valor"] or "", "valor_lido": valor or "",
               "versao": "" if versao is None else f"v{versao[0]}@N{versao[1]}",
               "desatualizada": 0, "nao_confirmada": 0}
        if st["op"] == "escrita" and status == "OK":
            hist = self.confirmadas.setdefault(st["chave"], [])
            if st["valor"] not in hist:
                hist.append(st["valor"])
        if st["op"] == "leitura" and status == "OK" and st["esperado"] is not None:
            hist = self.confirmadas.get(st["chave"], [])
            if valor is None:
                reg["desatualizada"] = 1
            elif valor in hist:
                reg["desatualizada"] = int(hist.index(valor) < hist.index(st["esperado"]))
            else:
                reg["nao_confirmada"] = 1
        self.resultados.append(reg)


# =============================================================================
# CENÁRIOS (os mesmos para os dois protocolos)
# =============================================================================
CENARIOS = {
    "normal": {"titulo": "Operação normal", "duracao": 2000, "eventos": []},
    "falha_secundario": {"titulo": "Falha de um secundário (N4)", "duracao": 3000,
                         "eventos": [(600, "falhar", 4), (1800, "recuperar", 4)], "falha": 4},
    "falha_primario": {"titulo": "Falha do primário (N0)", "duracao": 3000,
                       "eventos": [(600, "falhar", 0), (1800, "recuperar", 0)], "falha": 0},
    "particao_2_3": {"titulo": "Partição 2 + 3 (primário na minoria)", "duracao": 3000,
                     "eventos": [(600, "particionar", [[0, 1], [2, 3, 4]]), (1800, "curar", None)]},
    "particao_2_2_1": {"titulo": "Partição 2 + 2 + 1 (sem maioria)", "duracao": 3000,
                       "eventos": [(600, "particionar", [[0, 1], [2, 3], [4]]), (1600, "curar", None)]},
    "rede_instavel": {"titulo": "Rede instável (partição 2 + 3 e depois N4 parado)", "duracao": 3200,
                      "eventos": [(600, "particionar", [[0, 1], [2, 3, 4]]), (1600, "curar", None),
                                  (1900, "falhar", 4), (2500, "recuperar", 4)]},
}
CENARIOS_PRINCIPAIS = ["normal", "falha_secundario", "falha_primario", "particao_2_3", "particao_2_2_1"]
CONFIGS_QUORUM = [(3, 3), (4, 2), (2, 4), (5, 1), (1, 5), (2, 2), (1, 1)]


def montar(protocolo: str, semente: int, W: int = 3, R: int = 3, verbose: bool = False):
    sim = Simulador(semente, verbose)
    for i in range(N):
        sim.nos[i] = NoPrimarioSecundario(sim, i) if protocolo == "PS" else NoQuorum(sim, i, W, R)
    sim.cliente = Cliente(sim, protocolo)
    for i in range(N):
        sim.nos[i].iniciar(primeiro=(i == 0))
    return sim


def aplicar_evento(sim: Simulador, acao: str, arg) -> None:
    if acao == "falhar":
        sim.falhar(arg)
    elif acao == "recuperar":
        sim.recuperar(arg)
    elif acao == "particionar":
        sim.particionar(arg)
    elif acao == "curar":
        sim.curar()


def executar_cenario(protocolo: str, cenario: str, semente: int, W: int = 3, R: int = 3, verbose: bool = False):
    """Executa um cenário com carga contínua e devolve (sim, métricas)."""
    cfg = CENARIOS[cenario]
    sim = montar(protocolo, semente, W, R, verbose)
    cli = sim.cliente
    fim_carga = cfg["duracao"]
    for (t, acao, arg) in cfg["eventos"]:
        sim.agendar(t, aplicar_evento, sim, acao, arg)
    contador = [0]

    def gerar_carga():
        if sim.agora >= fim_carga:
            return
        contador[0] += 1
        k = contador[0]
        cli.operar("escrita", f"P{k:04d}", f"R$ {10 + k % 90},00|AUTORIZADO", cenario=cenario)
        sim.agendar(INTERVALO_CARGA / 2, gerar_leitura)
        sim.agendar(INTERVALO_CARGA, gerar_carga)

    def gerar_leitura():
        chaves = list(cli.confirmadas)
        if chaves:
            cli.operar("leitura", sim.rng.choice(chaves[-30:]), cenario=cenario)

    sim.agendar(INICIO_CARGA, gerar_carga)
    sim.rodar_ate(fim_carga + ASSENTAMENTO)
    return sim, medir(sim, protocolo, cenario, semente, W, R)


# =============================================================================
# MÉTRICAS
# =============================================================================
def _p95(valores):
    if not valores:
        return None
    v = sorted(valores)
    return v[min(len(v) - 1, int(round(0.95 * (len(v) - 1))))]


def estado_final(sim: Simulador, protocolo: str) -> dict:
    """Estado observado ao final: primário (PS) ou maior versão entre todos (quórum)."""
    if protocolo == "PS":
        lideres = [n for n in sim.nos.values() if n.papel == "PRIMARIO" and n.id in sim.ativos]
        return dict(lideres[0].estado) if lideres else {}
    final = {}
    for no in sim.nos.values():
        for chave, (v, valor) in no.kv.items():
            if chave not in final or v > final[chave][0]:
                final[chave] = (v, valor)
    return {k: v[1] for k, v in final.items()}


def convergiu(sim: Simulador, protocolo: str) -> bool:
    estados = []
    for no in sim.nos.values():
        if protocolo == "PS":
            estados.append({e["chave"]: e["valor"] for e in no.log[:no.commit] if e["chave"] is not None})
        else:
            estados.append({k: v for k, v in no.kv.items()})
    return all(e == estados[0] for e in estados)


def medir(sim: Simulador, protocolo: str, cenario: str, semente: int, W: int, R: int) -> dict:
    res = sim.cliente.resultados
    esc = [r for r in res if r["op"] == "escrita"]
    lei = [r for r in res if r["op"] == "leitura"]
    esc_ok = [r for r in esc if r["status"] in ("OK", "DUPLICADA", "REJEITADA_ID_CONFLITANTE")]
    lei_ok = [r for r in lei if r["status"] == "OK"]
    cfg = CENARIOS[cenario]
    ev = sim.eventos
    m = {"protocolo": "Primário-secundário" if protocolo == "PS" else "Quórum",
         "config": "-" if protocolo == "PS" else f"W={W} R={R}",
         "cenario": cenario, "semente": semente,
         "escritas": len(esc), "escritas_ok": len(esc_ok),
         "leituras": len(lei), "leituras_ok": len(lei_ok),
         "disp_escrita_pct": round(100 * len(esc_ok) / len(esc), 2) if esc else None,
         "disp_leitura_pct": round(100 * len(lei_ok) / len(lei), 2) if lei else None,
         "lat_escrita_media": round(statistics.mean(r["latencia_ms"] for r in esc_ok), 2) if esc_ok else None,
         "lat_escrita_p95": _p95([r["latencia_ms"] for r in esc_ok]),
         "lat_leitura_media": round(statistics.mean(r["latencia_ms"] for r in lei_ok), 2) if lei_ok else None,
         "lat_leitura_p95": _p95([r["latencia_ms"] for r in lei_ok]),
         "leituras_desatualizadas": sum(r["desatualizada"] for r in lei_ok),
         "mensagens": sim.mensagens}
    # tempos ligados à primeira perturbação do cenário
    t_falha = cfg["eventos"][0][0] if cfg["eventos"] else None
    m["t_deteccao_ms"] = m["t_eleicao_ms"] = m["t_novo_primario_ms"] = None
    m["t_retomada_escrita_ms"] = m["t_ressincronizacao_ms"] = m["janela_indisponivel_ms"] = None
    if t_falha is not None:
        alvo = cfg.get("falha")
        if protocolo == "PS":
            if alvo is not None and alvo != 0:
                det = [e for e in ev if e[0] >= t_falha and e[1] == "SUSPEITA_SECUNDARIO" and e[3] == alvo]
            else:
                det = [e for e in ev if e[0] >= t_falha and e[1] == "SUSPEITA_PRIMARIO"]
        else:
            det = [e for e in ev if e[0] >= t_falha and e[1] == "SUSPEITA" and (alvo is None or e[3] == alvo)]
        if det:
            m["t_deteccao_ms"] = round(det[0][0] - t_falha, 2)
        if protocolo == "PS":
            ele = [e for e in ev if e[0] >= t_falha and e[1] == "ELEITO"]
            if ele and det and (alvo in (None, 0)):
                m["t_novo_primario_ms"] = round(ele[0][0] - t_falha, 2)
                m["t_eleicao_ms"] = round(ele[0][0] - det[0][0], 2)
        # retomada: primeira escrita iniciada após a falha (ou após a cura, se não há maioria)
        ref = t_falha
        if cenario == "particao_2_2_1":
            ref = cfg["eventos"][1][0]
        depois = [r for r in esc_ok if r["t_inicio"] >= ref]
        if depois:
            m["t_retomada_escrita_ms"] = round(min(r["t_fim"] for r in depois) - ref, 2)
        # janela de indisponibilidade: maior intervalo sem nenhuma escrita confirmada
        fins = sorted([t_falha] + [r["t_fim"] for r in esc if r["status"] == "OK" and r["t_fim"] > t_falha])
        fins = [t for t in fins if t <= cfg["duracao"] + PRAZO_OPERACAO]
        m["janela_indisponivel_ms"] = round(max(b - a for a, b in zip(fins, fins[1:])), 2) if len(fins) > 1 else None
        ress = [e for e in ev if e[1] == "RESSINCRONIZADO"]
        retornos = [e for e in ev if e[1] == "RETORNO"]
        if ress and retornos:
            m["t_ressincronizacao_ms"] = round(ress[0][0] - retornos[0][0], 2)
    # consistência final
    final = estado_final(sim, protocolo)
    perdidos = sum(1 for k, hist in sim.cliente.confirmadas.items() if final.get(k) != hist[-1])
    m["confirmados_perdidos"] = perdidos
    m["conflitos_versao"] = sum(getattr(n, "conflitos", 0) for n in sim.nos.values())
    m["convergiu"] = int(convergiu(sim, protocolo))
    m["eleicoes"] = sum(1 for e in ev if e[1] == "ELEITO")
    return m


# =============================================================================
# CENÁRIOS ESPECIAIS: concorrência (versionamento) e idempotência
# =============================================================================
def executar_concorrencia(protocolo: str, semente: int, verbose: bool = False) -> dict:
    """Duas atualizações do mesmo pagamento, no mesmo instante, por nós diferentes."""
    sim = montar(protocolo, semente, verbose=verbose)
    cli = sim.cliente
    sim.agendar(300, lambda: cli.operar("escrita", "P9000", "R$ 80,00|AUTORIZADO", cenario="concorrencia"))
    sim.agendar(700, lambda: cli.operar("escrita", "P9000", "R$ 80,00|ESTORNADO", modo="atualizar",
                                        alvo=1, cenario="concorrencia"))
    sim.agendar(700, lambda: cli.operar("escrita", "P9000", "R$ 80,00|LIQUIDADO", modo="atualizar",
                                        alvo=3, cenario="concorrencia"))
    sim.agendar(1100, lambda: cli.operar("leitura", "P9000", cenario="concorrencia"))
    sim.rodar_ate(2500)
    final = estado_final(sim, protocolo)
    atualiz = [r for r in cli.resultados if r["op"] == "escrita" and r["status"] == "OK"
               and r["valor_enviado"].split("#")[0].endswith(("ESTORNADO", "LIQUIDADO"))]
    if protocolo == "PS":
        # cada atualização ocupa sua própria posição no log: nenhuma é descartada
        lider = [n for n in sim.nos.values() if n.papel == "PRIMARIO"][0]
        no_log = [e for e in lider.log[:lider.commit] if e["chave"] == "P9000"
                  and e["valor"].split("#")[0].endswith(("ESTORNADO", "LIQUIDADO"))]
        descartadas = len(atualiz) - len(no_log)
        ordem = " -> ".join(e["valor"].split("#")[0].split("|")[1] for e in no_log)
    else:
        # mesma versão (contador) para as duas => uma é descartada pelo desempate
        contadores = [r["versao"].split("@")[0] for r in atualiz]
        descartadas = len(contadores) - len(set(contadores))
        ordem = " | ".join(f'{r["valor_enviado"].split("#")[0].split("|")[1]} {r["versao"]}' for r in atualiz)
    return {"protocolo": "Primário-secundário" if protocolo == "PS" else "Quórum", "semente": semente,
            "atualizacoes_confirmadas": len(atualiz), "atualizacoes_descartadas": descartadas,
            "ordem_ou_versoes": ordem, "valor_final": (final.get("P9000") or "").split("#")[0].split("|")[1],
            "conflitos_versao": sum(getattr(n, "conflitos", 0) for n in sim.nos.values()),
            "convergiu": int(convergiu(sim, protocolo))}


def executar_idempotencia(protocolo: str, semente: int, verbose: bool = False) -> list:
    sim = montar(protocolo, semente, verbose=verbose)
    cli = sim.cliente
    sim.agendar(300, lambda: cli.operar("escrita", "P8000", "R$ 50,00|AUTORIZADO", cenario="idempotencia"))
    sim.agendar(600, lambda: cli.operar("escrita", "P8000", "R$ 50,00|AUTORIZADO", cenario="idempotencia"))
    sim.agendar(900, lambda: cli.operar("escrita", "P8000", "R$ 51,00|AUTORIZADO", cenario="idempotencia"))
    sim.rodar_ate(2000)
    final = estado_final(sim, protocolo)
    out = []
    for i, r in enumerate([r for r in cli.resultados if r["op"] == "escrita"], start=1):
        out.append({"protocolo": "Primário-secundário" if protocolo == "PS" else "Quórum", "semente": semente,
                    "tentativa": i, "valor_enviado": r["valor_enviado"].split("#")[0].split("|")[0],
                    "status": r["status"], "valor_final": (final.get("P8000") or "").split("#")[0].split("|")[0]})
    return out


# =============================================================================
# EXECUÇÃO DOS EXPERIMENTOS E GRAVAÇÃO DOS CSVs
# =============================================================================
METRICAS_RESUMO = ["disp_escrita_pct", "disp_leitura_pct", "lat_escrita_media", "lat_escrita_p95",
                   "lat_leitura_media", "lat_leitura_p95", "leituras_desatualizadas", "t_deteccao_ms",
                   "t_eleicao_ms", "t_novo_primario_ms", "t_retomada_escrita_ms", "janela_indisponivel_ms",
                   "t_ressincronizacao_ms",
                   "confirmados_perdidos", "conflitos_versao", "convergiu", "eleicoes", "mensagens"]


def salvar_csv(caminho: Path, linhas: list) -> None:
    caminho.parent.mkdir(parents=True, exist_ok=True)
    with caminho.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(linhas[0]))
        w.writeheader()
        w.writerows(linhas)


def resumir(execucoes: list) -> list:
    grupos: dict = {}
    for e in execucoes:
        grupos.setdefault((e["protocolo"], e["config"], e["cenario"]), []).append(e)
    linhas = []
    for (prot, conf, cen), runs in grupos.items():
        for met in METRICAS_RESUMO:
            vals = [r[met] for r in runs if r[met] is not None]
            if not vals:
                continue
            linhas.append({"protocolo": prot, "config": conf, "cenario": cen, "metrica": met,
                           "n": len(vals), "media": round(statistics.mean(vals), 2),
                           "desvio": round(statistics.stdev(vals), 2) if len(vals) > 1 else 0.0,
                           "minimo": round(min(vals), 2), "maximo": round(max(vals), 2)})
    return linhas


def main() -> None:
    ap = argparse.ArgumentParser(description="AVA3 – primário-secundário × quórum (simulação).")
    ap.add_argument("--sementes", type=int, default=30, help="Repetições por cenário (padrão 30).")
    ap.add_argument("--saida", default="resultados", help="Pasta dos CSVs.")
    ap.add_argument("--demo", action="store_true", help="Mostra a linha do tempo de dois cenários (semente 1).")
    args = ap.parse_args()

    if args.demo:
        for prot, cen in (("PS", "falha_primario"), ("Q", "falha_primario"), ("PS", "particao_2_3")):
            print(f"\n=== {'PRIMÁRIO-SECUNDÁRIO' if prot == 'PS' else 'QUÓRUM W=3 R=3'} | {CENARIOS[cen]['titulo']} ===")
            _, m = executar_cenario(prot, cen, 1, verbose=True)
            print(f"  -> escritas {m['escritas_ok']}/{m['escritas']}, detecção {m['t_deteccao_ms']} ms, "
                  f"retomada {m['t_retomada_escrita_ms']} ms, perdidos {m['confirmados_perdidos']}")
        return

    saida = Path(args.saida)
    sementes = range(1, args.sementes + 1)
    execucoes, operacoes, eventos_txt = [], [], []
    print(f"Executando {len(sementes)} sementes por cenário...")
    for cen in CENARIOS_PRINCIPAIS + ["rede_instavel"]:
        for prot in ("PS", "Q"):
            for s in sementes:
                sim, m = executar_cenario(prot, cen, s)
                execucoes.append(m)
                if s == 1:
                    for r in sim.cliente.resultados:
                        operacoes.append({"protocolo": m["protocolo"], "config": m["config"], **r})
                    eventos_txt.append(f"\n===== {m['protocolo']} {m['config']} | {CENARIOS[cen]['titulo']} | semente 1")
                    eventos_txt += [f"t={t:8.1f} ms  [{tp}] {tx}" for (t, tp, _, _, tx) in sim.eventos]
        print(f"  ok: {cen}")
    for (W, R) in CONFIGS_QUORUM:
        if (W, R) == (3, 3):
            continue                                     # já executado acima
        for s in sementes:
            _, m = executar_cenario("Q", "rede_instavel", s, W, R)
            execucoes.append(m)
    print("  ok: configurações de quórum")
    concorrencia = [executar_concorrencia(p, s) for p in ("PS", "Q") for s in sementes]
    idempotencia = executar_idempotencia("PS", 1) + executar_idempotencia("Q", 1)

    salvar_csv(saida / "execucoes.csv", execucoes)
    salvar_csv(saida / "resumo.csv", resumir(execucoes))
    salvar_csv(saida / "operacoes_semente1.csv", operacoes)
    salvar_csv(saida / "concorrencia.csv", concorrencia)
    salvar_csv(saida / "idempotencia.csv", idempotencia)
    (saida / "eventos_semente1.txt").write_text("\n".join(eventos_txt), encoding="utf-8")

    # resumo no terminal
    print("\nRESUMO (média das sementes) — W=3 R=3 no quórum")
    print(f"{'cenário':<18}{'protocolo':<22}{'disp.esc%':>10}{'detecção':>10}{'retomada':>10}{'perdidos':>9}")
    for cen in CENARIOS_PRINCIPAIS:
        for prot in ("Primário-secundário", "Quórum"):
            runs = [e for e in execucoes if e["cenario"] == cen and e["protocolo"] == prot
                    and e["config"] in ("-", "W=3 R=3")]
            def med(k):
                v = [r[k] for r in runs if r[k] is not None]
                return f"{statistics.mean(v):.1f}" if v else "-"
            print(f"{cen:<18}{prot:<22}{med('disp_escrita_pct'):>10}{med('t_deteccao_ms'):>10}"
                  f"{med('t_retomada_escrita_ms'):>10}{med('confirmados_perdidos'):>9}")
    print(f"\nCSVs gravados em: {saida.resolve()}")
    print("ATENÇÃO: simulação didática; tempos em milissegundos SIMULADOS, não medidos em rede real.")


if __name__ == "__main__":
    main()
