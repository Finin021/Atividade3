# -*- coding: utf-8 -*-
"""
AVA3 — Gerador das figuras do relatório (arquivo SEPARADO dos simuladores).

Não simula nada: só LÊ os CSVs da pasta resultados/ e desenha os gráficos.
Os simuladores continuam usando apenas a biblioteca padrão; só este script
precisa do matplotlib (pip install matplotlib).

Ordem de execução (na pasta do projeto):
    1) python pratica3_consenso_pagamentos_ava3.py                    # Prática 1 (versão AVA3)
    2) python pratica3_consenso_pagamentos_ava3.py --versao original  # Prática 1 (versão da aula)
    3) python ava3_protocolos.py                                      # Prática 2 (protocolos)
    4) python gerar_graficos_ava3.py                                  # figuras/ (7 PNGs)
"""
import csv
import statistics
import sys
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch, Patch

RES = Path("resultados")
FIG = Path("figuras")
DPI = 220
plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Liberation Sans", "DejaVu Sans"]

AZUL, LARANJA, VERDE, VERMELHO, CINZA = "#1F3A5F", "#D9822B", "#2E7D32", "#C62828", "#9E9E9E"
PS, Q = "Primário-secundário", "Quórum"
COR = {PS: AZUL, Q: LARANJA}
NOMES = {"normal": "Normal", "falha_secundario": "Falha de\nsecundário", "falha_primario": "Falha do\nprimário",
         "particao_2_3": "Partição\n2 + 3", "particao_2_2_1": "Partição\n2 + 2 + 1", "rede_instavel": "Rede\ninstável"}


def ler(nome):
    p = RES / nome
    if not p.exists():
        sys.exit(f"Não achei {p}. Rode antes os simuladores (veja o cabeçalho deste arquivo).")
    with p.open(encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def resumo():
    d = defaultdict(dict)
    for r in ler("resumo.csv"):
        d[(r["protocolo"], r["config"], r["cenario"])][r["metrica"]] = (float(r["media"]), float(r["desvio"]))
    return d


def chave(prot):
    return (prot, "-" if prot == PS else "W=3 R=3")


def limpar(ax):
    ax.spines[["top", "right"]].set_visible(False)


# -----------------------------------------------------------------------------
def fig1_arquitetura():
    fig, axs = plt.subplots(1, 2, figsize=(9.2, 4.0))
    import math
    for ax, titulo in zip(axs, ["(a) Primário-secundário", "(b) Quórum (N = 5, W = 3, R = 3)"]):
        ax.set_xlim(-1.9, 1.9); ax.set_ylim(-1.75, 1.75); ax.set_aspect("equal"); ax.axis("off")
        ax.set_title(titulo, fontsize=11, fontweight="bold", color=AZUL)
    # (a) estrela: primário no centro
    ax = axs[0]
    pos = {0: (0, 0)}
    for k, n in enumerate([1, 2, 3, 4]):
        a = math.radians(45 + 90 * k)
        pos[n] = (1.25 * math.cos(a), 1.25 * math.sin(a))
    for n in [1, 2, 3, 4]:
        ax.add_patch(FancyArrowPatch(pos[0], pos[n], arrowstyle="-|>", mutation_scale=12, color=AZUL,
                                     lw=1.4, shrinkA=24, shrinkB=22))
    for n, (x, y) in pos.items():
        prim = n == 0
        ax.add_patch(Circle((x, y), 0.33, fc=AZUL if prim else "white", ec=AZUL, lw=1.8))
        ax.text(x, y, f"N{n}", ha="center", va="center", fontsize=10, fontweight="bold",
                color="white" if prim else AZUL)
    ax.text(0, -0.55, "primário", ha="center", fontsize=8.5, color=AZUL, fontweight="bold")
    ax.text(0, -1.68, "log + heartbeat (50 ms) do primário para os secundários;\nconfirma com 3 de 5; eleição se o primário cair",
            ha="center", fontsize=8, color="#333")
    ax.annotate("cliente", xy=(-0.33, 0.12), xytext=(-1.75, 0.55), fontsize=8.5, color=VERDE,
                arrowprops=dict(arrowstyle="-|>", color=VERDE, lw=1.2))
    # (b) anel: coordenador qualquer
    ax = axs[1]
    pos = {}
    for n in range(5):
        a = math.radians(90 + 72 * n)
        pos[n] = (1.15 * math.cos(a), 1.15 * math.sin(a))
    for n in range(1, 5):
        ax.add_patch(FancyArrowPatch(pos[0], pos[n], arrowstyle="-|>", mutation_scale=11,
                                     color=LARANJA if n in (1, 4) else CINZA, lw=1.3 if n in (1, 4) else 0.9,
                                     ls="-" if n in (1, 4) else "--", shrinkA=22, shrinkB=22))
    for n, (x, y) in pos.items():
        ax.add_patch(Circle((x, y), 0.3, fc=LARANJA if n == 0 else "white", ec=LARANJA, lw=1.8))
        ax.text(x, y, f"N{n}", ha="center", va="center", fontsize=10, fontweight="bold",
                color="white" if n == 0 else LARANJA)
    ax.text(0.42, 1.25, "coordenador\n(qualquer nó)", ha="left", va="center", fontsize=8, color=LARANJA, fontweight="bold")
    ax.text(0, -1.68, "envia a todos e espera W = 3 confirmações (escrita)\nou R = 3 respostas (leitura); vence a maior versão",
            ha="center", fontsize=8, color="#333")
    ax.annotate("cliente", xy=(pos[0][0], pos[0][1] + 0.3), xytext=(-1.75, 1.5), fontsize=8.5, color=VERDE,
                arrowprops=dict(arrowstyle="-|>", color=VERDE, lw=1.2))
    plt.tight_layout()
    plt.savefig(FIG / "fig1_arquitetura.png", dpi=DPI)
    plt.close()


def fig2_linha_do_tempo():
    ops = [r for r in ler("operacoes_semente1.csv") if r["cenario"] == "falha_primario" and r["op"] == "escrita"
           and r["config"] in ("-", "W=3 R=3")]
    fig, axs = plt.subplots(2, 1, figsize=(8.6, 4.6), sharex=True)
    for ax, prot in zip(axs, (PS, Q)):
        rs = [r for r in ops if r["protocolo"] == prot]
        ok = [r for r in rs if r["status"] == "OK"]
        ax.scatter([float(r["t_inicio"]) for r in ok], [float(r["latencia_ms"]) for r in ok], s=9, color=COR[prot],
                   label="escrita confirmada")
        nok = [r for r in rs if r["status"] != "OK"]
        if nok:
            ax.scatter([float(r["t_inicio"]) for r in nok], [float(r["latencia_ms"]) for r in nok], s=14,
                       marker="x", color=VERMELHO, label="não confirmada")
        ax.axvline(600, color=VERMELHO, ls="--", lw=1.2)
        ax.axvline(1800, color=VERDE, ls="--", lw=1.2)
        ax.text(590, ax.get_ylim()[1] * 0.88, "N0 para", color=VERMELHO, fontsize=8, ha="right")
        ax.text(1812, ax.get_ylim()[1] * 0.88, "N0 volta", color=VERDE, fontsize=8)
        ax.set_ylabel("latência (ms)", fontsize=9)
        ax.set_title(prot if prot == PS else "Quórum (W = 3, R = 3)", fontsize=10, fontweight="bold", color=COR[prot], loc="left")
        limpar(ax)
    axs[1].set_xlabel("instante em que a escrita foi enviada (ms simulados)", fontsize=9)
    plt.tight_layout()
    plt.savefig(FIG / "fig2_linha_do_tempo_falha_primario.png", dpi=DPI)
    plt.close()


def fig3_tempos(d):
    metricas = [("t_deteccao_ms", "Detecção\nda falha"), ("t_retomada_escrita_ms", "1ª escrita\nconfirmada"),
                ("janela_indisponivel_ms", "Maior intervalo\nsem escrita"), ("t_ressincronizacao_ms", "Ressincronização\ndo nó que volta")]
    fig, axs = plt.subplots(1, 2, figsize=(9.6, 3.8), sharey=True)
    for ax, cen, tit in zip(axs, ["falha_primario", "particao_2_3"], ["(a) Falha do primário (N0)", "(b) Partição 2 + 3"]):
        xs = range(len(metricas))
        for k, prot in enumerate((PS, Q)):
            vals = [d[(*chave(prot), cen)].get(m, (0, 0)) for m, _ in metricas]
            barras = ax.bar([x + (k - 0.5) * 0.38 for x in xs], [v[0] for v in vals], 0.38,
                            yerr=[v[1] for v in vals], capsize=3, color=COR[prot], label=prot if prot == PS else "Quórum W=3 R=3")
            for b, v in zip(barras, vals):
                if v[0] > 0:
                    ax.text(b.get_x() + b.get_width() / 2, v[0] + v[1] + 8, f"{v[0]:.0f}", ha="center", fontsize=7.5)
        if cen == "particao_2_3":
            ax.text(3, 25, "não se aplica\n(nenhum nó parou)", ha="center", fontsize=7.5, color="#555")
        ax.set_xticks(list(xs)); ax.set_xticklabels([n for _, n in metricas], fontsize=8)
        ax.set_title(tit, fontsize=10, fontweight="bold", color=AZUL)
        limpar(ax)
    axs[0].set_ylabel("ms simulados (média ± desvio, 30 execuções)", fontsize=8.5)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=2, frameon=False, fontsize=9, bbox_to_anchor=(0.5, 1.02))
    plt.tight_layout(rect=(0, 0, 1, 0.92))
    plt.savefig(FIG / "fig3_tempos_deteccao_recuperacao.png", dpi=DPI)
    plt.close()


def fig4_disponibilidade(d):
    cens = ["normal", "falha_secundario", "falha_primario", "particao_2_3", "particao_2_2_1"]
    fig, axs = plt.subplots(1, 2, figsize=(9.6, 3.6), sharey=True)
    for ax, met, tit in zip(axs, ["disp_escrita_pct", "disp_leitura_pct"], ["(a) Escritas atendidas em até 500 ms", "(b) Leituras atendidas em até 500 ms"]):
        xs = range(len(cens))
        for k, prot in enumerate((PS, Q)):
            vals = [d[(*chave(prot), c)][met][0] for c in cens]
            b = ax.bar([x + (k - 0.5) * 0.38 for x in xs], vals, 0.38, color=COR[prot], label=prot if prot == PS else "Quórum W=3 R=3")
            for bb, v in zip(b, vals):
                ax.text(bb.get_x() + bb.get_width() / 2, v + 1, f"{v:.0f}", ha="center", fontsize=7.5)
        ax.set_xticks(list(xs)); ax.set_xticklabels([NOMES[c] for c in cens], fontsize=8)
        ax.set_ylim(0, 112); ax.set_title(tit, fontsize=10, fontweight="bold", color=AZUL)
        limpar(ax)
    axs[0].set_ylabel("% das operações", fontsize=9)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=2, frameon=False, fontsize=9, bbox_to_anchor=(0.5, 1.02))
    plt.tight_layout(rect=(0, 0, 1, 0.92))
    plt.savefig(FIG / "fig4_disponibilidade.png", dpi=DPI)
    plt.close()


def fig5_latencia(d):
    cens = ["normal", "falha_primario", "particao_2_3"]
    itens = [("lat_escrita_media", "Escrita\nmédia"), ("lat_escrita_p95", "Escrita\np95"),
             ("lat_leitura_media", "Leitura\nmédia"), ("lat_leitura_p95", "Leitura\np95")]
    fig, axs = plt.subplots(1, 3, figsize=(10, 3.5), sharey=True)
    for ax, cen in zip(axs, cens):
        xs = range(len(itens))
        for k, prot in enumerate((PS, Q)):
            vals = [d[(*chave(prot), cen)][m][0] for m, _ in itens]
            b = ax.bar([x + (k - 0.5) * 0.38 for x in xs], vals, 0.38, color=COR[prot], label=prot if prot == PS else "Quórum W=3 R=3")
            for bb, v in zip(b, vals):
                ax.text(bb.get_x() + bb.get_width() / 2, v + 4, f"{v:.0f}", ha="center", fontsize=7)
        ax.set_xticks(list(xs)); ax.set_xticklabels([n for _, n in itens], fontsize=7.5)
        ax.set_title(NOMES[cen].replace("\n", " "), fontsize=10, fontweight="bold", color=AZUL)
        limpar(ax)
    axs[0].set_ylabel("latência (ms simulados)", fontsize=9)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=2, frameon=False, fontsize=9, bbox_to_anchor=(0.5, 1.03))
    plt.tight_layout(rect=(0, 0, 1, 0.9))
    plt.savefig(FIG / "fig5_latencia.png", dpi=DPI)
    plt.close()


def fig6_configuracoes(d):
    confs = ["W=3 R=3", "W=4 R=2", "W=2 R=4", "W=5 R=1", "W=1 R=5", "W=2 R=2", "W=1 R=1"]
    disp_e = [d[(Q, c, "rede_instavel")]["disp_escrita_pct"][0] for c in confs]
    disp_l = [d[(Q, c, "rede_instavel")]["disp_leitura_pct"][0] for c in confs]
    stale = [d[(Q, c, "rede_instavel")]["leituras_desatualizadas"][0] for c in confs]
    fig, axs = plt.subplots(1, 2, figsize=(10, 3.7))
    xs = range(len(confs))
    axs[0].bar([x - 0.2 for x in xs], disp_e, 0.4, color=LARANJA, label="escritas")
    axs[0].bar([x + 0.2 for x in xs], disp_l, 0.4, color=AZUL, label="leituras")
    axs[0].set_ylim(0, 128); axs[0].set_ylabel("% atendidas em até 500 ms", fontsize=9)
    axs[0].set_title("(a) Disponibilidade", fontsize=10, fontweight="bold", color=AZUL)
    axs[0].legend(frameon=False, fontsize=8, loc="upper center", ncol=2)
    cores = [VERDE if int(c.split()[0][2:]) + int(c.split()[1][2:]) > 5 else VERMELHO for c in confs]
    b = axs[1].bar(xs, stale, 0.55, color=cores)
    for bb, v in zip(b, stale):
        axs[1].text(bb.get_x() + bb.get_width() / 2, v + 0.4, f"{v:.1f}", ha="center", fontsize=8)
    axs[1].set_ylabel("leituras desatualizadas por execução", fontsize=9)
    axs[1].set_title("(b) Leituras desatualizadas (média)", fontsize=10, fontweight="bold", color=AZUL)
    axs[1].legend(handles=[Patch(color=VERDE, label="W + R > N"), Patch(color=VERMELHO, label="W + R ≤ N")],
                  frameon=False, fontsize=8, loc="upper left")
    for ax in axs:
        ax.set_xticks(list(xs)); ax.set_xticklabels([c.replace(" ", "\n") for c in confs], fontsize=8)
        limpar(ax)
    plt.tight_layout()
    plt.savefig(FIG / "fig6_configuracoes_quorum.png", dpi=DPI)
    plt.close()


def fig7_pratica1():
    def tot(nome, pol):
        d = {r["id_transacao"]: float(r["valor_reais"]) for r in ler(nome) if r["politica"] == pol and r["status"] == "CONFIRMADA"}
        return sum(d.values())
    pols = ["unanimidade", "maioria"]
    orig = [tot("pratica1_original.csv", p) for p in pols]
    mod = [tot("pratica1_ava3.csv", p) for p in pols]
    fig, ax = plt.subplots(figsize=(6.2, 3.2))
    xs = range(2)
    b1 = ax.bar([x - 0.18 for x in xs], orig, 0.36, color=CINZA, label="Aula (P002 = R$ 20; partição 2+3)")
    b2 = ax.bar([x + 0.18 for x in xs], mod, 0.36, color=AZUL, label="AVA3 (P002 = R$ 25; partição 3+2)")
    for bs in (b1, b2):
        for b in bs:
            ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 3, f"R$ {b.get_height():.0f}", ha="center", fontsize=8.5, fontweight="bold")
    ax.set_xticks(list(xs)); ax.set_xticklabels(["Unanimidade (5/5)", "Maioria (3/5)"])
    ax.set_ylim(0, max(orig + mod) * 1.25); ax.set_ylabel("valor confirmado (R$)", fontsize=9)
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    limpar(ax)
    plt.tight_layout()
    plt.savefig(FIG / "fig7_pratica1_totais.png", dpi=DPI)
    plt.close()


def main():
    FIG.mkdir(exist_ok=True)
    d = resumo()
    fig1_arquitetura()
    fig2_linha_do_tempo()
    fig3_tempos(d)
    fig4_disponibilidade(d)
    fig5_latencia(d)
    fig6_configuracoes(d)
    fig7_pratica1()
    print("Figuras salvas em:", FIG.resolve())


if __name__ == "__main__":
    main()
