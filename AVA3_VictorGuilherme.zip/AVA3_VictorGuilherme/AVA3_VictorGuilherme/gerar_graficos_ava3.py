# -*- coding: utf-8 -*-
"""
AVA3 — Gerador das figuras do relatório.

Este script é SEPARADO do simulador. Ele NÃO executa a simulação: só lê os CSVs
que o simulador gera e desenha os gráficos. Assim, o simulador continua sem
dependências externas (como pede o slide 9), e só este script precisa do matplotlib.

Passo a passo (na mesma pasta dos arquivos):
    1) python pratica3_consenso_pagamentos_ava3.py                    -> resultados/resultados_ava3.csv
    2) python pratica3_consenso_pagamentos_ava3.py --versao original  -> resultados/resultados_original.csv
    3) python gerar_graficos_ava3.py                                  -> pasta figuras/ com 4 PNGs

Requer: Python 3.9+ e matplotlib   (pip install matplotlib)

Figuras:
    fig1_topologias.png          Desenho das redes: íntegra, 2+3 (aula), 3+2 (AVA3) e 2+2+1.
                                 É um desenho explicativo; não usa o CSV.
    fig2_confirmacoes.png        Confirmações obtidas por cenário x mínimo exigido (CSV da AVA3).
    fig3_totais.png              Valor e quantidade de pagamentos confirmados (CSV da AVA3).
    fig4_original_vs_ava3.png    Comparação entre os totais da aula e os da versão modificada
                                 (precisa dos dois CSVs).
"""
import csv
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # gera os PNGs sem abrir janela
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Circle, FancyBboxPatch, Patch

# ----------------------------------------------------------------------------
# Configurações
# ----------------------------------------------------------------------------
PASTA_CSV = Path("resultados")
CSV_AVA3 = PASTA_CSV / "resultados_ava3.csv"
CSV_ORIGINAL = PASTA_CSV / "resultados_original.csv"
PASTA_SAIDA = Path("figuras")
DPI = 220

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Liberation Sans", "DejaVu Sans"]  # usa a 1ª disponível

AZUL, VERDE, VERMELHO = "#1F3A5F", "#2E7D32", "#C62828"
CINZA, AMARELO, ROXO, VERDE_AGUA = "#9E9E9E", "#F9A825", "#6A1B9A", "#00695C"

NOMES_CENARIOS = {
    "normal": "Normal",
    "um_servidor_fora": "N4 fora",
    "particao_2_3": "Partição 2+3",
    "particao_3_2": "Partição 3+2",
    "particao_2_2_1": "Partição 2+2+1",
    "rede_restaurada": "Rede restaurada",
    "duplicada": "Duplicada (P005)",
    "falha_lider": "Falha do líder",
}


# ----------------------------------------------------------------------------
# Funções de apoio
# ----------------------------------------------------------------------------
def ler_csv(caminho: Path) -> list[dict]:
    if not caminho.exists():
        return []
    with caminho.open(encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def cor_do_status(status: str) -> str:
    if status == "CONFIRMADA":
        return VERDE
    if status.startswith("DUPLICADA"):
        return AMARELO
    return VERMELHO  # REJEITADA_*


def totais(linhas: list[dict], politica: str):
    """Total confirmado e nº de pagamentos distintos. Só conta CONFIRMADA (a duplicada não soma)."""
    pagamentos = {r["id_transacao"]: float(r["valor_reais"])
                  for r in linhas if r["politica"] == politica and r["status"] == "CONFIRMADA"}
    return sum(pagamentos.values()), len(pagamentos)


def submetidos(linhas: list[dict]):
    """Total e quantidade de pagamentos DISTINTOS enviados (P001..P006), iguais nas duas políticas."""
    d = {r["id_transacao"]: float(r["valor_reais"]) for r in linhas}
    return sum(d.values()), len(d)


# ----------------------------------------------------------------------------
# Figura 1 — topologias (desenho explicativo)
# ----------------------------------------------------------------------------
def painel(ax, titulo, grupos, lider=0):
    ax.set_xlim(0, 10)
    ax.set_ylim(-0.05, 1.75)
    ax.axis("off")
    ax.set_aspect("equal")
    ax.set_title(titulo, fontsize=10.5, fontweight="bold", color=AZUL, pad=2)
    cores = [AZUL, ROXO, VERDE_AGUA]
    gap, larg_no = 0.5, 1.15
    larguras = [len(g) * larg_no + 0.2 for g in grupos]
    x = (10 - (sum(larguras) + gap * (len(grupos) - 1))) / 2
    for i, grupo in enumerate(grupos):
        ax.add_patch(FancyBboxPatch((x, 0.0), larguras[i], 1.5, boxstyle="round,pad=0.0,rounding_size=0.2",
                                    fc="none", ec=cores[i], lw=1.5, ls="--"))
        for k, no in enumerate(grupo):
            cx = x + 0.1 + larg_no * (k + 0.5)
            ax.add_patch(Circle((cx, 0.85), 0.38, fc="white", ec=AZUL, lw=2.6 if no == lider else 1.4))
            ax.text(cx, 0.85, f"N{no}", ha="center", va="center", fontsize=10, fontweight="bold", color=AZUL)
            if no == lider:
                ax.text(cx, 0.22, "líder", ha="center", fontsize=8.5, color=VERDE, fontweight="bold")
        x += larguras[i] + gap


def figura1_topologias():
    fig, axs = plt.subplots(4, 1, figsize=(5.8, 5.4))
    painel(axs[0], "(a) Rede íntegra — um grupo com 5 nós", [[0, 1, 2, 3, 4]])
    painel(axs[1], "(b) Partição 2 + 3 (aula) — líder N0 na minoria", [[0, 1], [2, 3, 4]])
    painel(axs[2], "(c) Partição 3 + 2 (AVA3) — líder N0 na maioria", [[0, 1, 2], [3, 4]])
    painel(axs[3], "(d) Partição 2 + 2 + 1 — nenhum grupo com 3 nós", [[0, 1], [2, 3], [4]])
    plt.tight_layout(h_pad=0.5)
    plt.savefig(PASTA_SAIDA / "fig1_topologias.png", dpi=DPI)
    plt.close()


# ----------------------------------------------------------------------------
# Figura 2 — confirmações x limiar
# ----------------------------------------------------------------------------
def figura2_confirmacoes(linhas):
    fig, axs = plt.subplots(1, 2, figsize=(8.4, 3.9), sharey=True)
    for ax, politica in zip(axs, ["unanimidade", "maioria"]):
        rs = [r for r in linhas if r["politica"] == politica]
        xs = list(range(len(rs)))
        valores = [int(r["confirmacoes"]) for r in rs]
        alturas = [max(v, 0.25) for v in valores]  # barrinha mínima só para as rejeitadas (0) ficarem visíveis
        ax.bar(xs, alturas, color=[cor_do_status(r["status"]) for r in rs], width=0.62, edgecolor="white")
        ax.axhline(int(rs[0]["minimo_exigido"]), color=AZUL, ls="--", lw=1.5)
        for x, h, v in zip(xs, alturas, valores):
            ax.text(x, h + 0.1, str(v), ha="center", fontsize=8.5)
        ax.set_xticks(xs)
        ax.set_xticklabels([NOMES_CENARIOS.get(r["cenario"], r["cenario"]) for r in rs],
                           rotation=35, ha="right", fontsize=8.5)
        ax.set_title(politica.capitalize(), fontsize=10.5, fontweight="bold", color=AZUL)
        ax.set_ylim(0, 6)
        ax.spines[["top", "right"]].set_visible(False)
    axs[0].set_ylabel("Confirmações registradas")
    fig.legend(handles=[Patch(color=VERDE, label="Confirmada"),
                        Patch(color=VERMELHO, label="Rejeitada (sem quórum)"),
                        Patch(color=AMARELO, label="Duplicada (sem cobrança)"),
                        Line2D([0], [0], color=AZUL, ls="--", label="Mínimo exigido (limiar)")],
               loc="upper center", ncol=4, frameon=False, fontsize=8.5, bbox_to_anchor=(0.5, 1.02))
    plt.tight_layout(rect=(0, 0, 1, 0.94))
    plt.savefig(PASTA_SAIDA / "fig2_confirmacoes.png", dpi=DPI)
    plt.close()


# ----------------------------------------------------------------------------
# Figura 3 — totais (calculados a partir do CSV)
# ----------------------------------------------------------------------------
def figura3_totais(linhas):
    vu, qu = totais(linhas, "unanimidade")
    vm, qm = totais(linhas, "maioria")
    vs, qs = submetidos(linhas)
    nomes = ["Unanimidade", "Maioria"]
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.2))

    barras = axs[0].bar(nomes, [vu, vm], color=[CINZA, AZUL], width=0.5)
    axs[0].axhline(vs, color=VERMELHO, ls=":", lw=1.3)
    axs[0].text(-0.42, vs + 4, f"total submetido: R$ {vs:.0f}", ha="left", fontsize=8, color=VERMELHO)
    for b, v in zip(barras, [vu, vm]):
        axs[0].text(b.get_x() + b.get_width() / 2, v + 4, f"R$ {v:.2f}".replace(".", ","),
                    ha="center", fontsize=9, fontweight="bold")
    axs[0].set_ylim(0, vs * 1.17)
    axs[0].set_title("Valor confirmado ao final", fontsize=10, fontweight="bold", color=AZUL)

    barras = axs[1].bar(nomes, [qu, qm], color=[CINZA, AZUL], width=0.5)
    axs[1].axhline(qs, color=VERMELHO, ls=":", lw=1.3)
    axs[1].text(-0.42, qs + 0.12, f"pagamentos distintos submetidos: {qs}", ha="left", fontsize=8, color=VERMELHO)
    for b, v in zip(barras, [qu, qm]):
        axs[1].text(b.get_x() + b.get_width() / 2, v + 0.1, str(v), ha="center", fontsize=9, fontweight="bold")
    axs[1].set_ylim(0, qs + 1)
    axs[1].set_title("Pagamentos distintos confirmados", fontsize=10, fontweight="bold", color=AZUL)

    for a in axs:
        a.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    plt.savefig(PASTA_SAIDA / "fig3_totais.png", dpi=DPI)
    plt.close()


# ----------------------------------------------------------------------------
# Figura 4 — versão da aula x versão AVA3
# ----------------------------------------------------------------------------
def figura4_comparacao(orig, mod):
    politicas = ["unanimidade", "maioria"]
    rotulos = ["Unanimidade", "Maioria"]
    v_o = [totais(orig, p)[0] for p in politicas]
    v_m = [totais(mod, p)[0] for p in politicas]
    q_o = [totais(orig, p)[1] for p in politicas]
    q_m = [totais(mod, p)[1] for p in politicas]
    larg = 0.34
    fig, axs = plt.subplots(1, 2, figsize=(7.6, 3.3))
    for ax, a, b, titulo, fmt in ((axs[0], v_o, v_m, "Valor confirmado ao final", "R$ {:.2f}"),
                                  (axs[1], q_o, q_m, "Pagamentos distintos confirmados", "{:d}")):
        xs = range(len(rotulos))
        b1 = ax.bar([x - larg / 2 for x in xs], a, larg, color=CINZA, label="Aula (P002 = R$ 20; partição 2+3)")
        b2 = ax.bar([x + larg / 2 for x in xs], b, larg, color=AZUL, label="AVA3 (P002 = R$ 25; partição 3+2)")
        for barras in (b1, b2):
            for r in barras:
                h = r.get_height()
                txt = fmt.format(h).replace(".", ",") if "R$" in fmt else fmt.format(int(h))
                ax.text(r.get_x() + r.get_width() / 2, h + (max(a + b) * 0.015), txt,
                        ha="center", fontsize=7.5, fontweight="bold")
        ax.set_xticks(list(xs))
        ax.set_xticklabels(rotulos)
        ax.set_ylim(0, max(a + b) * 1.22)
        ax.set_title(titulo, fontsize=10, fontweight="bold", color=AZUL)
        ax.spines[["top", "right"]].set_visible(False)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=2, frameon=False, fontsize=8.5, bbox_to_anchor=(0.5, 1.03))
    plt.tight_layout(rect=(0, 0, 1, 0.92))
    plt.savefig(PASTA_SAIDA / "fig4_original_vs_ava3.png", dpi=DPI)
    plt.close()


# ----------------------------------------------------------------------------
def main():
    mod = ler_csv(CSV_AVA3)
    if not mod:
        sys.exit(f"Não achei {CSV_AVA3}.\nRode antes: python pratica3_consenso_pagamentos_ava3.py")
    PASTA_SAIDA.mkdir(exist_ok=True)
    figura1_topologias()
    figura2_confirmacoes(mod)
    figura3_totais(mod)
    orig = ler_csv(CSV_ORIGINAL)
    if orig:
        figura4_comparacao(orig, mod)
    else:
        print(f"Aviso: {CSV_ORIGINAL} não existe; a Figura 4 foi ignorada.\n"
              "Para gerá-la: python pratica3_consenso_pagamentos_ava3.py --versao original")
    print("Figuras salvas em:", PASTA_SAIDA.resolve())


if __name__ == "__main__":
    main()
